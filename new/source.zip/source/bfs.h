#ifndef BFS_H
#define BFS_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <queue>
#include "maze.h"

using namespace std;

class BFS {
	public: 
		BFS();
		~BFS();
		void bfs(Maze* maze);
		int cost;
		int nodeNum;
		int maxDepth;
		int maxFrontier;
		int* parent; 
		int* level;
		queue<int> qx;
		queue<int> qy;
	private:
		int bfsHelper(Maze* maze);
};

#endif