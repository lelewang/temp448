
#ifndef MAZE_H
#define MAZE_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>

using namespace std;

class Maze {
	public:
		Maze(char const & mazeName);
		~Maze();
		char* buffer;
		int width() const;
		int height() const;
		int startX() const;
		int startY() const;
		int endX() const;
		int endY() const;
		
	private:
		int mW;
		int mH;
		int sX;
		int sY;
		int eX;
		int eY;
		
};

#endif